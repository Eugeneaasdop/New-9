﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ПР_9.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageFor.xaml
    /// </summary>
    public partial class PageFor : Page
    {
        public PageFor()
        {
            InitializeComponent();
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            ClsFrame.frmObject.Navigate(new PageDoWhile());
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            double x0 = Convert.ToDouble(txtX0.Text);
            double xk = Convert.ToDouble(txtXk.Text);
            double dx = Convert.ToDouble(txtDX.Text);
            double a = Convert.ToDouble(txtA.Text);
            double b = Convert.ToDouble(txtb.Text);
            double x = x0;
            for (;x <= xk;x += dx)
            {
                double y = 0.01 * (a + b*x) - Math.Exp(Math.Pow(x, 3) + b);
                lisTable.Items.Add($"x = {x}; y = {y}");
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClsFrame.frmObject.Navigate(new PageWhile());
        }

        private void txtb_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
